.. _sec-bibliography:

.. only:: html

    References
    ----------

.. bibliography:: bibliography.bib
    :style: alpha
    :all:
